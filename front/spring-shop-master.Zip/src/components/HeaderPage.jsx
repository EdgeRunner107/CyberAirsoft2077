import React from 'react'

const HeaderPage = () => {
    return (
        <div>
            <img src="/image/bg.jpg" width="100%"/>
        </div>
    )
}

export default HeaderPage