import React from 'react'

const FooterPage = () => {
    return (
        <div className='my-5'>
            <hr/>
            <h5 className='text-center'>Copyright 2023. KOSMO 홍길동 all rights reserved.</h5>
        </div>
    )
}

export default FooterPage